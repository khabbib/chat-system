package view.utilities;

public enum ButtonType {
    ContactList,
    Logout,
    ContactAdd,
    File,
    Send,
}
